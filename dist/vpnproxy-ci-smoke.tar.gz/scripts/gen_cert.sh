#!/usr/bin/env bash
set -euo pipefail

CERT_DIR="${1:-./certs}"
COMMON_NAME="${2:-vpn-proxy-server}"
DAYS="${3:-825}"

mkdir -p "${CERT_DIR}"

openssl req -x509 -newkey rsa:4096 \
  -keyout "${CERT_DIR}/server.key" \
  -out "${CERT_DIR}/server.crt" \
  -sha256 -days "${DAYS}" -nodes \
  -subj "/CN=${COMMON_NAME}"

chmod 600 "${CERT_DIR}/server.key"
echo "Generated:"
echo "  ${CERT_DIR}/server.crt"
echo "  ${CERT_DIR}/server.key"
