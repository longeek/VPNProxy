import argparse
import ipaddress
import tempfile
import unittest
from pathlib import Path

import server


class ServerParsingTests(unittest.TestCase):
    def test_parse_bootstrap_valid(self):
        host, port = server.parse_bootstrap_line(
            b'{"auth":"t1","host":"example.com","port":443}\n',
            {"t1"},
        )
        self.assertEqual(host, "example.com")
        self.assertEqual(port, 443)

    def test_parse_bootstrap_bad_auth(self):
        with self.assertRaises(server.AuthError):
            server.parse_bootstrap_line(
                b'{"auth":"bad","host":"example.com","port":443}\n',
                {"t1"},
            )

    def test_parse_bootstrap_invalid_payload(self):
        with self.assertRaises(ValueError):
            server.parse_bootstrap_line(b'{"auth":"t1","host":"","port":0}\n', {"t1"})

    def test_parse_bootstrap_invalid_json(self):
        with self.assertRaises(ValueError):
            server.parse_bootstrap_line(b"not-json\n", {"t1"})


class ServerConfigTests(unittest.TestCase):
    def test_load_allowed_tokens_from_file_and_cli(self):
        with tempfile.TemporaryDirectory() as tmp:
            token_file = Path(tmp) / "tokens.txt"
            token_file.write_text("# comment\nalpha\n\nbeta\n", encoding="utf-8")
            args = argparse.Namespace(token="admin", tokens_file=str(token_file))
            tokens = server.load_allowed_tokens(args)
            self.assertSetEqual(tokens, {"admin", "alpha", "beta"})

    def test_parse_allow_cidrs(self):
        networks = server.parse_allow_cidrs("127.0.0.1/32,10.0.0.0/8")
        self.assertEqual(len(networks), 2)
        self.assertIn(ipaddress.ip_address("127.0.0.1"), networks[0])

    def test_peer_allowed(self):
        networks = [ipaddress.ip_network("127.0.0.1/32")]
        self.assertTrue(server.peer_allowed(("127.0.0.1", 10000), networks))
        self.assertFalse(server.peer_allowed(("10.10.10.10", 10000), networks))
        self.assertTrue(server.peer_allowed(("10.10.10.10", 10000), []))
