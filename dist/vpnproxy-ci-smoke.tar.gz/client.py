#!/usr/bin/env python3
import argparse
import asyncio
import errno
import json
import logging
import os
import socket
import ssl
import uuid
from typing import Optional


LOG = logging.getLogger("vpn-proxy-client")


SOCKS_VERSION = 5


class SocksProtocolError(ValueError):
    def __init__(self, message: str, reply_code: int):
        super().__init__(message)
        self.reply_code = reply_code


class TunnelAuthError(ConnectionError):
    pass


class TunnelBackendError(ConnectionError):
    pass


async def pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except (ConnectionResetError, BrokenPipeError):
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except (ConnectionError, OSError, RuntimeError):
            pass


async def read_exact(reader: asyncio.StreamReader, size: int) -> bytes:
    data = await reader.readexactly(size)
    return data


async def socks5_handshake(
    reader: asyncio.StreamReader, writer: asyncio.StreamWriter
) -> tuple[str, int]:
    header = await read_exact(reader, 2)
    ver, nmethods = header[0], header[1]
    if ver != SOCKS_VERSION:
        raise SocksProtocolError("unsupported SOCKS version", 0x01)

    await read_exact(reader, nmethods)
    writer.write(bytes([SOCKS_VERSION, 0x00]))
    await writer.drain()

    req_header = await read_exact(reader, 4)
    ver, cmd, _rsv, atyp = req_header
    if ver != SOCKS_VERSION or cmd != 0x01:
        raise SocksProtocolError("only CONNECT is supported", 0x07)

    if atyp == 0x01:  # IPv4
        addr = await read_exact(reader, 4)
        host = socket.inet_ntop(socket.AF_INET, addr)
    elif atyp == 0x03:  # Domain
        ln = (await read_exact(reader, 1))[0]
        host = (await read_exact(reader, ln)).decode("utf-8", errors="ignore")
    elif atyp == 0x04:  # IPv6
        addr = await read_exact(reader, 16)
        host = socket.inet_ntop(socket.AF_INET6, addr)
    else:
        raise SocksProtocolError("unsupported ATYP", 0x08)

    port = int.from_bytes(await read_exact(reader, 2), "big")
    return host, port


async def send_socks_reply(writer: asyncio.StreamWriter, rep: int) -> None:
    writer.write(bytes([SOCKS_VERSION, rep, 0x00, 0x01]) + b"\x00\x00\x00\x00\x00\x00")
    await writer.drain()


def build_tls_context(
    ca_cert: Optional[str],
    insecure: bool,
) -> ssl.SSLContext:
    if insecure:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx

    if ca_cert:
        return ssl.create_default_context(cafile=ca_cert)
    return ssl.create_default_context()


def resolve_tunnel_tls(args: argparse.Namespace) -> tuple[ssl.SSLContext, Optional[str]]:
    # Reuse SSL context across sessions to avoid repeated CA loading and setup.
    ssl_ctx: Optional[ssl.SSLContext] = getattr(args, "_vpn_proxy_ssl_ctx", None)
    if ssl_ctx is None:
        ssl_ctx = build_tls_context(args.ca_cert, args.insecure)
        setattr(args, "_vpn_proxy_ssl_ctx", ssl_ctx)

    server_name = args.sni or (None if args.insecure else args.server)
    return ssl_ctx, server_name


def map_socks_reply(exc: BaseException) -> int:
    if isinstance(exc, SocksProtocolError):
        return exc.reply_code
    if isinstance(exc, TunnelAuthError):
        return 0x02  # connection not allowed by ruleset
    if isinstance(exc, ConnectionRefusedError):
        return 0x05
    if isinstance(exc, (socket.gaierror, TimeoutError, asyncio.TimeoutError)):
        return 0x04
    if isinstance(exc, OSError):
        if exc.errno in {errno.ENETUNREACH, 10051}:
            return 0x03
        if exc.errno in {errno.EHOSTUNREACH, 10065}:
            return 0x04
        if exc.errno in {errno.ECONNREFUSED, 10061}:
            return 0x05
    return 0x01


async def open_tunnel(
    target_host: str,
    target_port: int,
    args: argparse.Namespace,
    session_id: str,
) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
    last_exc: Optional[Exception] = None
    retries = max(0, args.connect_retries)
    ssl_ctx, server_name = resolve_tunnel_tls(args)
    for attempt in range(retries + 1):
        try:
            reader, writer = await asyncio.open_connection(
                host=args.server,
                port=args.server_port,
                ssl=ssl_ctx,
                server_hostname=server_name,
            )

            bootstrap = json.dumps(
                {"auth": args.token, "host": target_host, "port": target_port},
                separators=(",", ":"),
            ).encode("utf-8") + b"\n"
            writer.write(bootstrap)
            await writer.drain()

            status = await asyncio.wait_for(reader.readline(), timeout=10)
            if not status.startswith(b"OK"):
                writer.close()
                await writer.wait_closed()
                status_text = status.decode(errors="replace").strip()
                if status.startswith(b"ERR auth"):
                    raise TunnelAuthError(f"proxy server refused auth: {status_text}")
                raise TunnelBackendError(f"proxy server refused: {status_text}")

            if attempt > 0:
                LOG.info("[sid=%s] tunnel recovered after retry %s", session_id, attempt)
            return reader, writer
        except (
            ConnectionError,
            OSError,
            ssl.SSLError,
            TimeoutError,
            asyncio.TimeoutError,
        ) as exc:
            last_exc = exc
            if attempt >= retries:
                break
            delay = max(0.1, args.retry_delay * (2 ** attempt))
            LOG.warning(
                "[sid=%s] tunnel connect failed (%s), retrying in %.1fs [%s/%s]",
                session_id,
                exc,
                delay,
                attempt + 1,
                retries,
            )
            await asyncio.sleep(delay)

    raise ConnectionError(f"unable to open tunnel: {last_exc}")


async def handle_socks_client(
    client_reader: asyncio.StreamReader,
    client_writer: asyncio.StreamWriter,
    args: argparse.Namespace,
) -> None:
    session_id = uuid.uuid4().hex[:8]
    peer = client_writer.get_extra_info("peername")
    try:
        target_host, target_port = await socks5_handshake(client_reader, client_writer)
        LOG.debug(
            "[sid=%s] request from %s to %s:%s",
            session_id,
            peer,
            target_host,
            target_port,
        )

        tunnel_reader, tunnel_writer = await open_tunnel(
            target_host, target_port, args, session_id
        )
        await send_socks_reply(client_writer, 0x00)

        await asyncio.gather(
            pipe(client_reader, tunnel_writer),
            pipe(tunnel_reader, client_writer),
        )
    except (
        SocksProtocolError,
        ConnectionError,
        OSError,
        asyncio.IncompleteReadError,
        TimeoutError,
        asyncio.TimeoutError,
    ) as exc:
        reply_code = map_socks_reply(exc)
        LOG.warning(
            "[sid=%s] SOCKS request failed from %s: %s (reply=0x%02x)",
            session_id,
            peer,
            exc,
            reply_code,
        )
        try:
            await send_socks_reply(client_writer, reply_code)
        except (ConnectionError, OSError, RuntimeError):
            pass
        try:
            client_writer.close()
            await client_writer.wait_closed()
        except (ConnectionError, OSError, RuntimeError):
            pass


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Local SOCKS5 -> remote TLS tunnel proxy client"
    )
    parser.add_argument("--listen", default=os.getenv("VPN_PROXY_LOCAL_LISTEN", "127.0.0.1"))
    parser.add_argument(
        "--listen-port",
        type=int,
        default=int(os.getenv("VPN_PROXY_LOCAL_PORT", "1080")),
    )
    parser.add_argument("--server", default=os.getenv("VPN_PROXY_SERVER"), help="remote server host")
    parser.add_argument(
        "--server-port",
        type=int,
        default=int(os.getenv("VPN_PROXY_SERVER_PORT", "8443")),
    )
    parser.add_argument("--token", default=os.getenv("VPN_PROXY_TOKEN"), help="shared token")
    parser.add_argument("--ca-cert", default=os.getenv("VPN_PROXY_CA_CERT"))
    parser.add_argument("--sni", default=os.getenv("VPN_PROXY_SNI"))
    parser.add_argument(
        "--connect-retries",
        type=int,
        default=int(os.getenv("VPN_PROXY_CONNECT_RETRIES", "2")),
        help="number of retries when tunnel connection fails",
    )
    parser.add_argument(
        "--retry-delay",
        type=float,
        default=float(os.getenv("VPN_PROXY_RETRY_DELAY", "0.8")),
        help="initial retry delay seconds (exponential backoff)",
    )
    parser.add_argument(
        "--insecure",
        action="store_true",
        help="disable certificate verification (not recommended)",
    )
    parser.add_argument(
        "--log-level",
        default=os.getenv("VPN_PROXY_LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    return parser


async def main_async(args: argparse.Namespace) -> None:
    if not args.server:
        raise SystemExit("missing --server or VPN_PROXY_SERVER")
    if not args.token:
        raise SystemExit("missing --token or VPN_PROXY_TOKEN")

    server = await asyncio.start_server(
        lambda r, w: handle_socks_client(r, w, args),
        host=args.listen,
        port=args.listen_port,
    )

    sockets = ", ".join(str(sock.getsockname()) for sock in (server.sockets or []))
    LOG.info("local SOCKS5 started on %s", sockets)
    async with server:
        await server.serve_forever()


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
