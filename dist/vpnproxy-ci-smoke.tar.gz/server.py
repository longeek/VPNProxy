#!/usr/bin/env python3
import argparse
import asyncio
import ipaddress
import json
import logging
import os
import ssl
import uuid
from dataclasses import dataclass
from typing import Optional


LOG = logging.getLogger("vpn-proxy-server")


class AuthError(Exception):
    pass


@dataclass
class SessionStats:
    upload_bytes: int = 0
    download_bytes: int = 0


def load_allowed_tokens(args: argparse.Namespace) -> set[str]:
    tokens: set[str] = set()
    if args.token:
        tokens.add(args.token)

    if args.tokens_file:
        with open(args.tokens_file, "r", encoding="utf-8") as f:
            for line in f:
                token = line.strip()
                if token and not token.startswith("#"):
                    tokens.add(token)
    return tokens


def parse_allow_cidrs(value: Optional[str]) -> list[ipaddress._BaseNetwork]:
    if not value:
        return []
    items = [v.strip() for v in value.split(",") if v.strip()]
    networks: list[ipaddress._BaseNetwork] = []
    for item in items:
        networks.append(ipaddress.ip_network(item, strict=False))
    return networks


def peer_allowed(peer: object, allow_networks: list[ipaddress._BaseNetwork]) -> bool:
    if not allow_networks:
        return True
    if not isinstance(peer, tuple) or not peer:
        return False
    ip = ipaddress.ip_address(peer[0])
    return any(ip in net for net in allow_networks)


async def pipe(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    stats: SessionStats,
    is_upload: bool,
) -> None:
    try:
        while True:
            data = await reader.read(65536)
            if not data:
                break
            if is_upload:
                stats.upload_bytes += len(data)
            else:
                stats.download_bytes += len(data)
            writer.write(data)
            await writer.drain()
    except (ConnectionResetError, BrokenPipeError):
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except (ConnectionError, OSError, RuntimeError):
            pass


def parse_bootstrap_line(line: bytes, allowed_tokens: set[str]) -> tuple[str, int]:
    try:
        payload = json.loads(line.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError("invalid json") from exc

    token = payload.get("auth")
    host = payload.get("host")
    port = payload.get("port")

    if token not in allowed_tokens:
        raise AuthError("invalid auth token")
    if not isinstance(host, str) or not host:
        raise ValueError("invalid host")
    if not isinstance(port, int) or port < 1 or port > 65535:
        raise ValueError("invalid port")

    return host, port


async def handle_client(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    allowed_tokens: set[str],
    allow_networks: list[ipaddress._BaseNetwork],
    connect_timeout: float,
) -> None:
    session_id = uuid.uuid4().hex[:8]
    peer = writer.get_extra_info("peername")
    stats = SessionStats()
    target_writer: Optional[asyncio.StreamWriter] = None
    try:
        if not peer_allowed(peer, allow_networks):
            raise PermissionError("peer not in allow-cidrs")

        line = await asyncio.wait_for(reader.readline(), timeout=10)
        if not line:
            raise ValueError("empty bootstrap")

        host, port = parse_bootstrap_line(line, allowed_tokens)
        LOG.info(
            "[sid=%s] accepted tunnel from %s to %s:%s",
            session_id,
            peer,
            host,
            port,
        )

        target_reader, target_writer = await asyncio.wait_for(
            asyncio.open_connection(host, port),
            timeout=connect_timeout,
        )

        writer.write(b"OK\n")
        await writer.drain()

        await asyncio.gather(
            pipe(reader, target_writer, stats, True),
            pipe(target_reader, writer, stats, False),
        )
    except AuthError:
        LOG.warning("[sid=%s] auth failed from %s", session_id, peer)
        try:
            writer.write(b"ERR auth\n")
            await writer.drain()
        except (ConnectionError, OSError, RuntimeError):
            pass
    except (
        PermissionError,
        ValueError,
        asyncio.IncompleteReadError,
        TimeoutError,
        asyncio.TimeoutError,
        ConnectionError,
        OSError,
        ssl.SSLError,
    ) as exc:
        LOG.warning("[sid=%s] connection failed from %s: %s", session_id, peer, exc)
        try:
            writer.write(b"ERR connect\n")
            await writer.drain()
        except (ConnectionError, OSError, RuntimeError):
            pass
    finally:
        LOG.info(
            "[sid=%s] session closed from %s (up=%s bytes, down=%s bytes)",
            session_id,
            peer,
            stats.upload_bytes,
            stats.download_bytes,
        )
        try:
            writer.close()
            await writer.wait_closed()
        except (ConnectionError, OSError, RuntimeError):
            pass


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="TLS tunnel proxy server for Linux deployment"
    )
    parser.add_argument("--listen", default=os.getenv("VPN_PROXY_LISTEN", "0.0.0.0"))
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.getenv("VPN_PROXY_PORT", "8443")),
    )
    parser.add_argument(
        "--cert",
        default=os.getenv("VPN_PROXY_CERT", "./certs/server.crt"),
        help="TLS certificate path",
    )
    parser.add_argument(
        "--key",
        default=os.getenv("VPN_PROXY_KEY", "./certs/server.key"),
        help="TLS private key path",
    )
    parser.add_argument(
        "--token",
        default=os.getenv("VPN_PROXY_TOKEN"),
        help="shared token; env VPN_PROXY_TOKEN is supported",
    )
    parser.add_argument(
        "--tokens-file",
        default=os.getenv("VPN_PROXY_TOKENS_FILE"),
        help="optional file with one token per line",
    )
    parser.add_argument(
        "--allow-cidrs",
        default=os.getenv("VPN_PROXY_ALLOW_CIDRS", ""),
        help="comma-separated client IP CIDRs, e.g. 1.2.3.4/32,10.0.0.0/8",
    )
    parser.add_argument(
        "--connect-timeout",
        type=float,
        default=float(os.getenv("VPN_PROXY_CONNECT_TIMEOUT", "8")),
    )
    parser.add_argument(
        "--log-level",
        default=os.getenv("VPN_PROXY_LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    return parser


async def main_async(args: argparse.Namespace) -> None:
    allowed_tokens = load_allowed_tokens(args)
    if not allowed_tokens:
        raise SystemExit("missing token(s): set --token, --tokens-file or env var")
    allow_networks = parse_allow_cidrs(args.allow_cidrs)
    if allow_networks:
        LOG.info("allow-cidrs enabled with %d network(s)", len(allow_networks))

    ssl_ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ssl_ctx.load_cert_chain(certfile=args.cert, keyfile=args.key)
    ssl_ctx.minimum_version = ssl.TLSVersion.TLSv1_2

    server = await asyncio.start_server(
        lambda r, w: handle_client(
            r, w, allowed_tokens, allow_networks, args.connect_timeout
        ),
        host=args.listen,
        port=args.port,
        ssl=ssl_ctx,
    )

    sockets = ", ".join(str(sock.getsockname()) for sock in (server.sockets or []))
    LOG.info("server started on %s", sockets)
    async with server:
        await server.serve_forever()


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
